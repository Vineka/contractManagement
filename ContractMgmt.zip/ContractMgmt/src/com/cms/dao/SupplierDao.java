package com.cms.dao;

import java.text.ParseException;
import java.util.Date;
import java.util.List;

import com.cms.bean.SupplierBean;
import com.cms.exception.ApplicationException;

public interface SupplierDao {

	public SupplierBean loginSupplierCheck(int id) throws ApplicationException;

	public int addSupplier(SupplierBean supplierBean) throws ApplicationException;
	
	public SupplierBean fetchSupplier(int supplierId) throws ApplicationException;
	
	public List<SupplierBean> fetchAllSuppliers() throws ApplicationException;
	
	public void updateSupplierStatus(SupplierBean supplierBean) throws ApplicationException;
	
	public List<SupplierBean> fetchSupplier(String status) throws ApplicationException;

	public SupplierBean checkDate(SupplierBean supplierBean) throws ApplicationException, ParseException;

	public int passwordUpdate(int id, String password) throws ApplicationException;
	
}
