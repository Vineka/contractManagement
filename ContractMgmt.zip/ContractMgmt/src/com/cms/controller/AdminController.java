package com.cms.controller;

import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cms.bean.AdminBean;
import com.cms.bean.SupplierBean;
import com.cms.exception.ApplicationException;
import com.cms.service.AdminService;
import com.cms.service.ContractService;
import com.cms.service.SupplierService;

@Controller
public class AdminController {

	@Autowired
	AdminService adminService;

	@Autowired
	SupplierService supplierService;

	@Autowired
	ContractService contractService;

	static Logger log = Logger.getLogger("ContractMgmt");

	@RequestMapping(value = "/addAdmin", method = RequestMethod.POST)
	public ModelAndView saveAdmin(@ModelAttribute("command") AdminBean adminBean, BindingResult result,
			HttpSession session) {
		ModelAndView mav = null;
		int id = 0;

		try {

			id = adminService.addAdmin(adminBean);

		} catch (ApplicationException ae) {

			log.info(ae.getMessage());
			mav = new ModelAndView("applicationError");

		}

		mav = new ModelAndView("adminLogin", "successMessage1",
				"Successfully registered. Use this ID: " + id + " to login.");
		return mav;
	}

	@RequestMapping(value = "/loginAdmin", method = { RequestMethod.POST, RequestMethod.GET })
	public ModelAndView loginAdmin(@ModelAttribute("command") AdminBean adminBean1, BindingResult result,
			HttpSession session) {
		ModelAndView mav = null;
		AdminBean adminBean = null;

		try {

			adminBean = adminService.loginAdminCheck(adminBean1.getAdminId());
			session.setAttribute("adminBean", adminBean);

			if (adminBean1.getPassword().equals(adminBean.getPassword())
					&& adminBean1.getAdminId() == (adminBean.getAdminId())) {

				mav = new ModelAndView("admin");

			} else
				mav = new ModelAndView("adminLogin", "message1", "Invalid Username or Password");

		} catch (ApplicationException ae) {

			log.info(ae.getMessage());
			mav = new ModelAndView("applicationError");

		}

		return mav;
	}

	@RequestMapping(value = "/adminPasswordUpdate")
	public ModelAndView adminPasswordUpdate(@RequestParam("password1") String password, HttpServletRequest request,
			@ModelAttribute("command") AdminBean adminBean, BindingResult result, HttpSession session) {
		ModelAndView mav = null;
		int i = 0;

		try {
			if (adminBean.getPassword().equals(password)) {
				i = adminService.adminPasswordUpdate(adminBean.getAdminId(), password);
				if (i == 1)
					mav = new ModelAndView("adminLogin", "message1",
							"Password Changed Successfully.Please Login Again!");
				else
					mav = new ModelAndView("updatePasswordAdmin", "updateMessage", "No such Id found. Please Register");

			} else
				mav = new ModelAndView("updatePasswordAdmin", "updateMessage", "Password Doesn't Match");

		} catch (ApplicationException ae) {

			log.info(ae.getMessage());
			mav = new ModelAndView("applicationError");

		}

		return mav;
	}

}
